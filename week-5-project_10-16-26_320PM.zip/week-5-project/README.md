//DO-IT 
//To Do List App
//This is the first of many Apps to come from Justin Vincent
//A simple To-Do list app that allows you to add tasks and errands to-do for your day.
//Best Feature...VOICE COMMAND!!! Simply say "Add..." and it will be added to the list, "Check off..." to mark as completed and "Delete..." to remove it from your list
