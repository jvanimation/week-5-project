//DO-IT 
//To Do List App
//This is the first of many Apps to come from Justin Vincent
//A simple To-Do list app that allows you to add tasks and errands to-do for your day.
//Type in a task and click ADD and it will display numbered off. Double click title to make changes, type a discription of the title to add more details, check off to mark as complete and click the "X" to delete when no longer needed. Rearrange order of tasks by clicking and dragging up and down.
//Best Feature...VOICE COMMAND!!! Simply say "Add..." and it will be added to the list, "Check..." to mark as completed and "Delete..." to remove it from your list. WE WILL NEVER RECORD AND/OR REDISTRIBUTE YOUR VOICE WITHOUT YOUR KNOWLEGE OR CONCENT. PLEASE DON'T SUE!
//NEW FEATURE UPDATE!!-Date and Time added.