const newListItem = "<li class='task'>Nothing to see here</li>"

document.querySelector("#list").innerHTML += newListItem

function addTasks() {
    const list = document.querySelector("#list")

}

const tasks = []
const completed = new Set()
const list = document.querySelector("#list")
const tasksForm = document.querySelector("#taskForm")
const taskInput = document.querySelector("#taskInput")
const deleteTask = document.querySelector("#deleteTask")
const listError = document.querySelector("#listError")

// Name of the task currently being dragged (null when nothing is dragged)
let draggedName = null

function renderTasks() {
    list.innerHTML = "";

    tasks.forEach((taskName) => {
        const task = document.createElement("li")
        task.classList.add("task")
        task.draggable = true
        task.dataset.name = taskName

        const checkbox = document.createElement("input")
        checkbox.type = "checkbox"
        checkbox.classList.add("task-check")
        checkbox.checked = completed.has(taskName)
        checkbox.addEventListener("change", () => {
            if (checkbox.checked) {
                completed.add(taskName)
            } else {
                completed.delete(taskName)
            }
            renderTasks()
        })

        const label = document.createElement("span")
        label.textContent = taskName
        label.classList.toggle("done", completed.has(taskName))

        const deleteBtn = document.createElement("button")
        deleteBtn.type = "button"
        deleteBtn.textContent = "X"
        deleteBtn.classList.add("delete-x")
        deleteBtn.addEventListener("click", () => {
            const index = tasks.indexOf(taskName)
            tasks.splice(index, 1)
            completed.delete(taskName)
            renderTasks()
        })

        // --- Drag and drop ---
        task.addEventListener("dragstart", (e) => {
            draggedName = taskName
            e.dataTransfer.effectAllowed = "move"
            e.dataTransfer.setData("text/plain", taskName) // required by Firefox
            task.classList.add("dragging")
        })

        task.addEventListener("dragend", () => {
            draggedName = null
            task.classList.remove("dragging")
            document
                .querySelectorAll("#list li.drag-over")
                .forEach((li) => li.classList.remove("drag-over"))
        })

        task.addEventListener("dragover", (e) => {
            if (draggedName === null || draggedName === taskName) return
            e.preventDefault() // allows dropping here
            e.dataTransfer.dropEffect = "move"
            task.classList.add("drag-over")
        })

        task.addEventListener("dragleave", () => {
            task.classList.remove("drag-over")
        })

        task.addEventListener("drop", (e) => {
            e.preventDefault()
            task.classList.remove("drag-over")
            if (draggedName === null || draggedName === taskName) return

            const fromIndex = tasks.indexOf(draggedName)
            const toIndex = tasks.indexOf(taskName)

            // Remove from old spot, insert at the target's position
            const [moved] = tasks.splice(fromIndex, 1)
            tasks.splice(toIndex, 0, moved)

            draggedName = null
            renderTasks()
        })

        task.append(checkbox, label, deleteBtn)
        list.append(task)
    })
}

tasksForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const taskName = taskInput.value.trim()

    if (taskName == "") {
        listError.textContent = "Please enter a task name"
        return
    } else if (tasks.includes(taskName)) {
        listError.textContent = "That task is already in the list"
        return
    }
    listError.textContent = "";

    tasks.push(taskName)
    renderTasks()
    tasksForm.reset()
})

renderTasks();

taskInput.addEventListener("keydown", (event) => {
    console.log("Key pressed is: " + event.key)
})

taskInput.addEventListener("input", (event) => {
    console.log("Input is: " + event.target.value)
})

const title = document.querySelector("#title")

function titleHover() {
    console.log("Hovering over title(mouseover")
}

title.addEventListener("mouseover", titleHover)
title.style.color = "rgb(208, 208, 208)"
title.classList.add("highlight")

