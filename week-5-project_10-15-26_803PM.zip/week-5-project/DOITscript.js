const newListItem = "<li class='task'>Nothing to see here</li>"

document.querySelector("#list").innerHTML += newListItem

function addTasks() {
    const list = document.querySelector("#list")

}

// --- Saving / loading (localStorage) ---
const STORAGE_KEY = "doit-data"

function loadData() {
    try {
        return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {}
    } catch (err) {
        return {} // storage unavailable or data corrupted: start fresh
    }
}

function saveData() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify({ tasks: tasks }))
    } catch (err) {
        console.warn("Could not save tasks:", err)
    }
}

function makeId() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 8)
}

// Each task is { id, name, done, desc }.
// Migrates the old format (array of name strings + separate completed/descriptions).
function loadTasks(saved) {
    if (!Array.isArray(saved.tasks)) return []

    const oldCompleted = new Set(saved.completed || [])
    const oldDescriptions = new Map(saved.descriptions || [])

    return saved.tasks.map((t) => {
        if (typeof t === "string") {
            return {
                id: makeId(),
                name: t,
                done: oldCompleted.has(t),
                desc: oldDescriptions.get(t) || ""
            }
        }
        return t
    })
}

const saved = loadData()

const tasks = loadTasks(saved)
const list = document.querySelector("#list")
const tasksForm = document.querySelector("#taskForm")
const taskInput = document.querySelector("#taskInput")
const listError = document.querySelector("#listError")

// Id of the task currently being dragged (null when nothing is dragged)
let draggedId = null

function renderTasks() {
    list.innerHTML = "";

    tasks.forEach((taskData) => {
        const task = document.createElement("li")
        task.classList.add("task")
        task.draggable = true
        task.dataset.id = taskData.id

        const checkbox = document.createElement("input")
        checkbox.type = "checkbox"
        checkbox.classList.add("task-check")
        checkbox.checked = taskData.done
        checkbox.addEventListener("change", () => {
            taskData.done = checkbox.checked
            saveData()
            renderTasks()
        })

        const label = document.createElement("span")
        label.textContent = taskData.name
        label.classList.toggle("done", taskData.done)

        const deleteBtn = document.createElement("button")
        deleteBtn.type = "button"
        deleteBtn.textContent = "X"
        deleteBtn.classList.add("delete-x")
        deleteBtn.addEventListener("click", () => {
            const index = tasks.findIndex((t) => t.id === taskData.id)
            tasks.splice(index, 1)
            saveData()
            renderTasks()
        })

        const desc = document.createElement("textarea")
        desc.classList.add("task-desc")
        desc.placeholder = "Whachu doin' here..."
        desc.rows = 2
        desc.value = taskData.desc
        desc.addEventListener("input", () => {
            taskData.desc = desc.value // no re-render, so focus is kept
            saveData()
        })
        // Let the user select text inside the box instead of dragging the whole task
        desc.addEventListener("focus", () => { task.draggable = false })
        desc.addEventListener("blur", () => { task.draggable = true })

        // --- Drag and drop ---
        task.addEventListener("dragstart", (e) => {
            draggedId = taskData.id
            e.dataTransfer.effectAllowed = "move"
            e.dataTransfer.setData("text/plain", taskData.name) // required by Firefox
            task.classList.add("dragging")
        })

        task.addEventListener("dragend", () => {
            draggedId = null
            task.classList.remove("dragging")
            document
                .querySelectorAll("#list li.drag-over")
                .forEach((li) => li.classList.remove("drag-over"))
        })

        task.addEventListener("dragover", (e) => {
            if (draggedId === null || draggedId === taskData.id) return
            e.preventDefault() // allows dropping here
            e.dataTransfer.dropEffect = "move"
            task.classList.add("drag-over")
        })

        task.addEventListener("dragleave", () => {
            task.classList.remove("drag-over")
        })

        task.addEventListener("drop", (e) => {
            e.preventDefault()
            task.classList.remove("drag-over")
            if (draggedId === null || draggedId === taskData.id) return

            const fromIndex = tasks.findIndex((t) => t.id === draggedId)
            const toIndex = tasks.findIndex((t) => t.id === taskData.id)

            // Remove from old spot, insert at the target's position
            const [moved] = tasks.splice(fromIndex, 1)
            tasks.splice(toIndex, 0, moved)

            draggedId = null
            saveData()
            renderTasks()
        })

        task.append(checkbox, label, deleteBtn, desc)
        list.append(task)
    })
}

tasksForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const taskName = taskInput.value.trim()

    if (taskName == "") {
        listError.textContent = "Please enter a task name"
        return
    }
    listError.textContent = "";

    tasks.push({ id: makeId(), name: taskName, done: false, desc: "" })
    saveData()
    renderTasks()
    tasksForm.reset()
})

renderTasks();

taskInput.addEventListener("keydown", (event) => {
    console.log("Key pressed is: " + event.key)
})

taskInput.addEventListener("input", (event) => {
    console.log("Input is: " + event.target.value)
})

const title = document.querySelector("#title")

function titleHover() {
    console.log("Hovering over title(mouseover")
}

title.addEventListener("mouseover", titleHover)
title.style.color = "rgb(208, 208, 208)"
title.classList.add("highlight")


// --- Voice commands (Web Speech API) ---
// Try saying:
//   "add buy milk"            "complete buy milk"     "uncheck buy milk"
//   "delete buy milk"         "clear completed"
const voiceBtn = document.querySelector("#voiceBtn")
const voiceStatus = document.querySelector("#voiceStatus")
const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition

function setVoiceStatus(message) {
    voiceStatus.textContent = message
}

// Exact match first, then partial match ("milk" finds "Buy milk")
function findTaskByName(query) {
    const q = query.toLowerCase().trim()
    if (q === "") return null
    return (
        tasks.find((t) => t.name.toLowerCase() === q) ||
        tasks.find((t) => t.name.toLowerCase().includes(q)) ||
        null
    )
}

function handleVoiceCommand(rawText) {
    // Speech engines add capitalization and punctuation; strip trailing punctuation
    const spoken = rawText.trim().replace(/[.!?,]+$/, "")
    let m

    // "clear completed" (checked before "delete ..." so it isn't read as a task name)
    if (/^(?:clear|remove|delete)\s+(?:all\s+)?(?:completed|done|finished)(?:\s+tasks)?$/i.test(spoken)) {
        const before = tasks.length
        for (let i = tasks.length - 1; i >= 0; i--) {
            if (tasks[i].done) tasks.splice(i, 1)
        }
        const removed = before - tasks.length
        saveData()
        renderTasks()
        setVoiceStatus(removed ? `Cleared ${removed} completed task(s).` : "No completed tasks to clear.")
        return
    }

    // "add buy milk" / "add a new task called buy milk"
    if ((m = spoken.match(/^(?:add|new|create)(?:\s+a)?(?:\s+new)?(?:\s+task)?(?:\s+(?:called|named))?\s+(.+)$/i))) {
        const name = m[1].charAt(0).toUpperCase() + m[1].slice(1)
        tasks.push({ id: makeId(), name: name, done: false, desc: "" })
        listError.textContent = ""
        saveData()
        renderTasks()
        setVoiceStatus(`Added "${name}".`)
        return
    }

    // "uncheck buy milk" (checked before "complete" so wording can't collide)
    if ((m = spoken.match(/^(?:uncheck|uncomplete|undo|reopen)\s+(.+)$/i))) {
        const task = findTaskByName(m[1])
        if (!task) return setVoiceStatus(`Couldn't find a task matching "${m[1]}".`)
        task.done = false
        saveData()
        renderTasks()
        return setVoiceStatus(`Unchecked "${task.name}".`)
    }

    // "complete buy milk" / "check off buy milk" / "mark buy milk as done"
    if ((m = spoken.match(/^(?:complete|finish|check(?:\s+off)?|mark)\s+(.+?)(?:\s+as\s+(?:done|complete|completed|finished))?$/i))) {
        const task = findTaskByName(m[1])
        if (!task) return setVoiceStatus(`Couldn't find a task matching "${m[1]}".`)
        task.done = true
        saveData()
        renderTasks()
        return setVoiceStatus(`Completed "${task.name}".`)
    }

    // "delete buy milk" / "remove buy milk"
    if ((m = spoken.match(/^(?:delete|remove)\s+(.+)$/i))) {
        const task = findTaskByName(m[1])
        if (!task) return setVoiceStatus(`Couldn't find a task matching "${m[1]}".`)
        tasks.splice(tasks.indexOf(task), 1)
        saveData()
        renderTasks()
        return setVoiceStatus(`Deleted "${task.name}".`)
    }

    setVoiceStatus(`Didn't understand "${spoken}". Try "add ...", "complete ...", "delete ...", or "clear completed".`)
}

if (!SpeechRecognitionAPI) {
    voiceBtn.disabled = true
    setVoiceStatus("Voice commands aren't supported in this browser (try Chrome, Edge, or Safari).")
} else {
    const recognition = new SpeechRecognitionAPI()
    recognition.lang = "en-US"
    recognition.interimResults = false
    recognition.maxAlternatives = 1
    recognition.continuous = false
    let listening = false

    voiceBtn.addEventListener("click", () => {
        try {
            if (listening) recognition.stop()
            else recognition.start()
        } catch (err) {
            console.warn("Voice recognition error:", err)
        }
    })

    recognition.addEventListener("start", () => {
        listening = true
        voiceBtn.classList.add("listening")
        setVoiceStatus('Listening… say "add buy milk", "complete buy milk", "delete buy milk"')
    })

    recognition.addEventListener("end", () => {
        listening = false
        voiceBtn.classList.remove("listening")
    })

    recognition.addEventListener("result", (event) => {
        const transcript = event.results[0][0].transcript
        console.log("Heard: " + transcript)
        handleVoiceCommand(transcript)
    })

    recognition.addEventListener("error", (event) => {
        if (event.error === "not-allowed" || event.error === "service-not-allowed") {
            setVoiceStatus("Microphone access was blocked. Allow it in your browser's site settings.")
        } else if (event.error === "no-speech") {
            setVoiceStatus("Didn't hear anything. Click the mic and try again.")
        } else {
            setVoiceStatus("Voice error: " + event.error)
        }
    })
}